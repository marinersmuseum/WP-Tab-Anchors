=== WP Tab Anchors ===
Contributors: AdamBCarrier
Tags: tabs, anchors, Bootstrap tabs
Donate link: http://www.marinersmuseum.org/donate
Requires at least: 3.8
Tested up to: 3.9.2
Stable tag: 1.2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows you to permalink (i.e., bookmark) to content on Twitter Bootstrap tabs (and now content inside collapsible components) via hash tag links.

== Description ==
This plugin allows you to permalink (i.e., bookmark) to content on Twitter Bootstrap tabs (and now content inside collapsible components) via hash tag links.

Out-of-the-box, Bootstrap won't allow you to permalink to the tabs (or inside collapsible components). This plugin activates the tab containing the permalinked content and then scrolls the page to the hash tag (i.e., to the HTML element with the ID specified in the hash tag). You don't even have to know which tab the content is on; the plugin figures it out. It does this so quick you really won't notice all this going on. Page visitors who arrive using your permalink will pretty much immediately see the content you permalinked.

You can contribute to this plugin here:  https://github.com/marinersmuseum/WP-Tab-Anchors
